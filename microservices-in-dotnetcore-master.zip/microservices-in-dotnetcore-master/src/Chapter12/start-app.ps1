start-process dotnet -ArgumentList run -WorkingDirectory ./Login
start-process dotnet -ArgumentList run -WorkingDirectory ./ProductCatalog
start-process dotnet -ArgumentList run -WorkingDirectory ./ShoppingCart
start-process dotnet -ArgumentList run -WorkingDirectory ./ApiGateway