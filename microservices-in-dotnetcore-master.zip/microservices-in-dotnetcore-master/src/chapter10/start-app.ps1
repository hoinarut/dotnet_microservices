start-process dotnet -ArgumentList run -WorkingDirectory ./IdentityServer
start-process dotnet -ArgumentList run -WorkingDirectory ./LoyaltyProgram
start-process dotnet -ArgumentList run -WorkingDirectory ./ApiGatewayMock 
